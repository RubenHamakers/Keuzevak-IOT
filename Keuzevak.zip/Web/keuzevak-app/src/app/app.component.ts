import { Component } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { NgxChartsModule } from '@swimlane/ngx-charts';
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'keuzevak-app';
  data = null;
  processedData = [{
    'name': 'Open seats',
    'series': [
      {
        'name': '18:42:13',
        'value': 8
      }]
  }];

  multi: any[];

  view: any[] = [400, 500];

  // Define room TODO: WEBPAGE FOR ROOM CREATION AND COUPLING WITH THINGSPEAK CHANNEL
  room = {
    seats: 20,
    people: 0
  };

  // CHART OPTIONS
  legend = false;
  showLabels = true;
  animations = true;
  xAxis = true;
  yAxis = true;
  showYAxisLabel = true;
  showXAxisLabel = true;
  xAxisLabel = '';
  yAxisLabel = 'Open seats';
  timeline = true;

  colorScheme = {
    domain: ['#5AA454', '#E44D25', '#CFC0BB', '#7aa3e5', '#a8385d', '#aae3f5']
  };

  // OBTAIN THINGSPEAK DATA AND START PROCESSING
  constructor(private http: HttpClient) {
    this.getData().subscribe(
      (response) => {
        this.data = response;
      }, error => console.log(error),
      () => {
        console.log(this.data);
        this.processData();
      }
    );
  }

  // PUSH DATA TO READABLE FORMAT FOR CHART AND UPDATE ROOM STATUS
  processData() {
    this.data.feeds.forEach((element, index) => {
      let tostr = this.data.feeds[index].created_at;
      tostr = tostr.toString();
      this.processedData['0'].series.push({
        'name': tostr.substring(11, tostr.length - 1),
        'value': this.room.seats - Math.ceil(this.data.feeds[index].field1),
      });
      this.room.people = Math.ceil(this.data.feeds[index].field1);
    });
    this.multi = this.processedData;
  }

  getData() {
    return this.http.get('https://api.thingspeak.com/channels/953101/feeds.json?api_key=UNDBIYTEHPK8Y93A&results=20');
  }



}
